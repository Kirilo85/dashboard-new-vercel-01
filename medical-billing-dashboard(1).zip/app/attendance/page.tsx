import HealthcareAttendanceDashboard from "@/components/healthcare-attendance-dashboard"

export default function AttendancePage() {
  return <HealthcareAttendanceDashboard />
}
